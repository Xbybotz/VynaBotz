import { createRequire } from 'module'
const require = createRequire(import.meta.url)
const version = require("baileys/package.json").version 
global.require = require
global.language = "id"
global.nomerOwner ="6282389924037"// ganti sesuka hati lo
global.nomerOwner2 = ""// ganti sesuka hati lo
global.runWith = "Replit"
global.ownerName = "Vynaachan"// ganti sesuka hati lo
global.botName = "VynaBotz" // ganti sesuka hati lo
global.sessionName ="session" //untuk session rm- rf session
global.setmenu ="document" // gak ush lo ganti
global.docType = "docx" // ga ush di ganti
global.Qoted = "ftoko" // ga ush di ganti
global.autoBio = false // tanya lana kalo mau aktifin auto bio
global.baileysMd = true
global.antiSpam = true
//global.multi = true
//global.prefa = "!"
global.fake = botName
global.Console = false
//global.autorespon = false
global.copyright = `Baileys ${version}`
global.baileysVersion = `Baileys ${version}`
//global.On = "On"
//global.Off ="Off"
//global.autoblockcmd = false
global.fake1 ="VynaBotz"
global.packName = "vynaabotz"
global.authorName = "VynaTeam"
global.replyType = "web"
global.setwelcome = "type11"
global.autoblockcmd = false
global.autoReport = true
global.autoLevel = true
global.autoSticker = false // true untuk kirim foto otomatis jd stiker
global.gamewaktu = 60
global.limitCount = 30 // untuk limit user
global.Intervalmsg = 1000 //detik
global.fileStackApi ="" //daftar di filestack
global.apiflash ="9b9e84dfc18746d4a19d3afe109e9ea4"
global.apikey ="XTRAM" //daftar di website https://api.lolhuman.xyz/

// make apikey lolhuman 

//global.anonymousImg = "https://telegra.ph/file/1446ae19e40a769e94248.jpg"
//global.botImg = "https://telegra.ph/file/67f456acc78d2252dde2f.jpg"
//global.fakegifImg ="https://telegra.ph/file/b4ec766d46519110784c3.jpg"
//global.quotedImg = "https://telegra.ph/file/037f85737e981c7158d3d.jpg"
//global.replyImg = "https://telegra.ph/file/861077ba89491ed8cc6f1.jpg"
//global.thumbImg ="https://telegra.ph/file/2b5e7da186256332c9dc8.jpg"
//global.thumbnaildokumenImg = "https://telegra.ph/file/67f88bf1209262d81ffe8.jpg"
//global.videoMp4 = "https://telegra.ph/file/fcc8a8d9ea62088fb9f4b.mp4"
//global.webImg = "https://telegra.ph/file/f7da244c6cbf47f55f59b.jpg"
global.gcounti = {
'prem' : 60, //limit prem
'user' : 20 //limit
} 


// SCRIPT BY : LANA DEV
// EROR?? CHAT GROUP : https://chat.whatsapp.com/JgJHpvM7K6UAYVlT2zQPFA
// JANGAN DI HAPUS ASU
// JUAL SCRIPT?? NERAKA PALING BAWAH


//===================//
