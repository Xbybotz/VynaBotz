no## Lana Bot V.1 ESM
<img src="https://telegra.ph/file/2677c6ca6d9b2a372d009.jpg" alt="LANA" width="360" />

---

## Information
> Lana bot adalah script bot untuk public , yang di kembangkan oleh [Lana Dev](https://maulanabot.my.id) , dan awal mula memakai base dari [Amelia-Botz](http://youtube.com/officialdittaz) .
> Jika kamu menemukan semacam bug, harap untuk dimaklumi sementara

## Connect With Me
[`Klik Disini`](https://wa.me/6285773089737)

## Bugs and Tester
* Jika kamu menemukan bug atau error
* Info Lebih Lanjut, Chat [Dev LanaSad](https://wa.me/6285773089737)

# Requirements
* [Node.js](https://nodejs.org/en/)
* [Git](https://git-scm.com/downloads)
* [FFmpeg](https://github.com/BtbN/FFmpeg-Builds/releases/download/autobuild-2020-12-08-13-03/ffmpeg-n4.3.1-26-gca55240b8c-win64-gpl-4.3.zip) (for sticker command)

## Heroku Buildpack
```bash
 heroku/nodejs
 https://github.com/jonathanong/heroku-buildpack-ffmpeg-latest
 https://github.com/clhuang/heroku-buildpack-webp-binaries.git
```

## Donate
- [Saweria](https://)
- [Dana](http://)
- [Ovo](https://)
- [Gopay](https://)

# Official Group 
- [LANA BOT](https://chat.whatsapp.com/JgJHpvM7K6UAYVlT2zQPFA)

# Thanks to
 <a href="https://github.com/hexagonz"><img src="https://https://github.com/hexagonz.png?size=100" width="100" height="100"></a> | [![FERDIZ](https://github.com/hexagonz.png?size=100)](https://github.com/hexagonz-afk) | [![RASHID](https://github.com/hexagonz.png?size=100)](https://github.com/hexagonz) 
---|---|---
[Adiwajshing](https://github.com/adiwajshing/Baileys)  | [Hexagonz](https://github.com/hexagonz) |
Owner of Baileys | Constributor | Constributor


 <a href="https://github.com/hexagonz"><img src="https://https://github.com/hexagonz.png?size=100" width="100" height="100"></a> | [![FERDIZ](https://github.com/hexagonz.png?size=100)](https://github.com/hexagonz-afk) | [![RASHID](https://github.com/hexagonz.png?size=100)](https://github.com/hexagonz) 
 ---|---|---
[Official Dittaz](https://github.com/officialdittaz)| [YogiPw](https://github.com/yogipw) | 
Owner Amelia - Botz | For Help | 

##
* [`Baileys`](https://github.com/adiwajshing/Baileys)
* [`Hexagonz`](https://github.com/hexagonz)
* [`Yogipw`](https://github.com/yogipw)

> Run Pake PM@ + COLOR

> run = "FORCE_COLOR=1 pm2 start index.js && pm2 save && pm2 save && pm2 logs --raw"

> Hapus Node Modules : rm -r node_modules

> Edit Node Modules : mv node_modules edit

> Hapus Session : rm -rf session



